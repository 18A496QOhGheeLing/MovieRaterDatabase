package com.nyp.sit.movierater

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.RadioGroup
import com.nyp.sit.movierater.R.id.menu_save


import com.nyp.sit.movierater.data.MovieRating
import kotlinx.android.synthetic.main.activity_add_movie.*
import kotlinx.android.synthetic.main.activity_edit_movie.*

class EditMovieActivity : AppCompatActivity() {

    var mr: MovieRating? = null
    var pos = 0


    var mrApp: MovieRaterApplication? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_movie)
        this.actionBar?.setDisplayHomeAsUpEnabled(true)
        mrApp = MovieRaterApplication.getInstance()

        var Movie = MovieRating("Venom", "Overview", "English",
                "19-10-2018", true, false)

        em_movietitleET.setText(Movie.name.toString())
        em_moviedescriptionET.setText(Movie.description.toString())
        em_moviedateET.setText(Movie.releasedate.toString())

        em_movielanguageRG.clearCheck()
        if(Movie.langauge == "English")
            em_rbtnEng.setChecked(true)
        else if(Movie.langauge == "Chinese")
            em_rbtnChi.setChecked(true)
        else if(Movie.langauge == "Malay")
            em_rbtnMal.setChecked(true)
        else  (Movie.langauge == "Tamil")
            em_rbtnTam.setChecked(true)

        if(Movie.violent == true)
            em_chkBoxViolence.setChecked(true)
        else
            em_chkBoxViolence.setChecked(false)

        if(Movie.langaugeused == true)
            em_chkBoxLanguage.setChecked(true)
        else
            em_chkBoxLanguage.setChecked(false)

        if (Movie.violent == true || Movie.langaugeused == true)
            em_chkBoxAudience.setChecked(true)
        else
            em_chkBoxAudience.setChecked(false)

        em_chkBoxAudience.setOnClickListener {
            if (em_chkBoxAudience.isChecked == true ) {
                em_chkBoxViolence.setVisibility(View.VISIBLE)
                em_chkBoxLanguage.setVisibility(View.VISIBLE)
            }
            else {
                em_chkBoxViolence.setVisibility(View.INVISIBLE)
                em_chkBoxLanguage.setVisibility(View.INVISIBLE)
                em_chkBoxViolence.setChecked(false)
                em_chkBoxLanguage.setChecked(false)
            }

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater?.inflate(R.menu.menu_edit,menu)
        return super.onCreateOptionsMenu(menu)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId == menu_save)
        {
            var intent: Intent?= Intent (this,MovieDetail::class.java)
            var display_language: String = ""
            var display_suitability: String?= ""
            var display_language_used_in_movie: String? = ""
            var display_violence_used_in_movie: String? = ""

            intent?.putExtra("message", "Edit")
            intent?.putExtra("movie_name", em_movietitleET.text.toString())
            intent?.putExtra("movie_description", em_moviedescriptionET.text.toString())
            intent?.putExtra("movie_release_date", em_moviedateET.text.toString())

            if(em_rbtnEng.isChecked)
            display_language = "English"
            else if(em_rbtnChi.isChecked)
                display_language = "Chinese"
            else if(em_rbtnMal.isChecked)
                display_language="Malay"
            else if(em_rbtnTam.isChecked)
                display_language="Tamil"
            intent?.putExtra("movie_language", display_language)

            if(em_chkBoxAudience.isChecked)
                display_suitability = "Yes"
                else
                display_suitability= "No"
            if(em_chkBoxViolence.isChecked)
                display_violence_used_in_movie = " (Violence)"
            if(em_chkBoxLanguage.isChecked)
                display_language_used_in_movie = " (Language Used)"
            intent?.putExtra("movie_suitability",
                    display_suitability+display_violence_used_in_movie+display_language_used_in_movie)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }

}
