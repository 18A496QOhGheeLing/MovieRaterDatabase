package com.nyp.sit.movierater

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.*
import android.widget.RatingBar
import android.widget.Toast
import com.nyp.sit.movierater.R.id.menuitem_submit

import kotlinx.android.synthetic.main.activity_movie_detail.*
import kotlinx.android.synthetic.main.activity_rating.*

class RatingActivity : AppCompatActivity() {

    //var rating_bar_input: String? = ""
    //var shareviewET_input: String? = ""
    var mrApp: MovieRaterApplication? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rating)
        this.actionBar?.setDisplayHomeAsUpEnabled(true)
        mrApp = MovieRaterApplication.getInstance()
        MovieRaterApplication

        spacer_above_ra_movie_name.text = intent.getStringExtra("menu_review")

        var FromActivity = intent.getStringExtra("message")
            if (FromActivity == "Details")
                ra_movie_nameTV.text = intent.getStringExtra("movie_title")
        else
                ra_movie_nameTV.text = "Venom"

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater?.inflate(R.menu.menu_submit, menu)
        return true
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        if (item?.itemId == menuitem_submit) {
            val output = Intent()
            output.putExtra("Ratings-stars", rating_bar.rating.toFloat())
            output.putExtra("Ratings_details", ra_share_viewET.text.toString())
            setResult(RESULT_OK, output)
            finish()
        }
        return super.onOptionsItemSelected(item)

    }






}