package com.nyp.sit.movierater

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.RadioGroup
import android.widget.Toast
import com.nyp.sit.movierater.R.id.*
import com.nyp.sit.movierater.R.menu.menu_add
import com.nyp.sit.movierater.data.MovieRating
import kotlinx.android.synthetic.main.activity_add_movie.*
import kotlinx.android.synthetic.main.activity_add_movie.view.*

class AddMovieActivity : AppCompatActivity() {
    //var langType : String? = ""
    //var checkBoxLang: String? = "Language"
   // var checkBoxViol: String? = ""

    var mrApp: MovieRaterApplication? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_movie)
        this.actionBar?.setDisplayHomeAsUpEnabled(true)
        var FromMain = intent.getStringExtra("message")


        mrApp = MovieRaterApplication.getInstance()
        if (FromMain != "Main") {
            var Movie = MovieRating("Avengers",
                    "Movie about people hitting each other",
                    "English",
                    "2010", false, false)
            am_movietitleET.setText(Movie.name.toString())
            am_moviedescriptionET.setText(Movie.description.toString())
            am_moviedateET.setText(Movie.releasedate.toString())
            am_movielanguageRG.clearCheck()
            if (Movie.langauge == "English")
                am_rbtnEng.setChecked(true)
            else if (Movie.langauge == "Chinese")
                am_rbtnChi.setChecked(true)
            else if (Movie.langauge == "Malay")
                am_rbtnMal.setChecked(true)
            else (Movie.langauge == "Tamil")
            am_rbtnTam.setChecked(true)

            if (Movie.violent == true)
                chkBoxViolence.setChecked(true)
            else
                chkBoxViolence.setChecked(false)
            if (Movie.langaugeused == true)
                chkBoxLanguage.setChecked(true)
            else
                chkBoxLanguage.setChecked(false)
            if (Movie.violent == true || Movie.langaugeused == true)
                chkBoxAudience.setChecked(true)
            else
                chkBoxAudience.setChecked(false)
                chkBoxAudience.setChecked(true)
        }

        chkBoxAudience.setOnClickListener {
            if (chkBoxAudience.isChecked == true) {
                chkBoxViolence.setVisibility(View.VISIBLE)
                chkBoxLanguage.setVisibility(View.VISIBLE)
            } else {
                chkBoxViolence.setVisibility(View.INVISIBLE)
                chkBoxLanguage.setVisibility(View.INVISIBLE)
                chkBoxViolence.setChecked(false)
                chkBoxLanguage.setChecked(false)
            }

        }


    }

        //btnSubmit.setOnClickListener {
            //if (am_movietitleET.text.toString().isEmpty())
               // am_movietitleET.error = "Empty field"
            //if (am_moviedescriptionET.text.toString().isEmpty())
                //am_moviedescriptionET.error = "Empty field"
            //if( am_moviedateET.text.toString().isEmpty())
                //am_moviedateET.error = "Empty field"
            //if (am_movietitleET.text.toString().isNotEmpty()
                    //&& am_moviedescriptionET.text.toString().isNotEmpty()
                   // && am_moviedateET.text.toString().isNotEmpty())


               // displayToast( "Title = " + am_movietitleET.getText().toString() +
                        //"\n Overview = " + am_moviedescriptionET.getText().toString() +
                        //"\n Release date = " + am_moviedateET.getText().toString() +
                        //"\n Language = " + langType +
                        //"\n Suitable for all ages = " + (chkBoxAudience.isChecked) +
                        //"\n Reason:\n" + checkBoxLang +
                        //"\n" + checkBoxViol
                //)
            //}


        //am_movielanguageRG.setOnCheckedChangeListener(object: RadioGroup.OnCheckedChangeListener{
           // override fun onCheckedChanged(group: RadioGroup?, checkedId: Int) {
               // if(checkedId == R.id.am_rbtnEng)
                //{
                   // langType = "English"
               //}

               // else if(checkedId == R.id.am_rbtnChi)
                //{
                    //langType = "Chinese"
                //}
                //else if(checkedId == R.id.am_rbtnMal)
                //{
                  //  langType = "Malay"
                //}
                //else if(checkedId == R.id.am_rbtnTam)
                //{
                   // langType = "Tamil"
                //}
            //}
       // })

       // chkBoxAudience.setOnClickListener {
            //if(chkBoxAudience.isChecked == true)
            //{
               // chkBoxLanguage.setVisibility(View.VISIBLE);
               // chkBoxViolence.setVisibility(View.VISIBLE);


           // }
           // else
           // {
              //  chkBoxLanguage.setVisibility(View.INVISIBLE);
               // chkBoxViolence.setVisibility(View.INVISIBLE);
           // }
        //}
        //chkBoxLanguage.setOnClickListener {
            //if (chkBoxLanguage.isChecked == true)
           // {
              //  checkBoxLang = "Language";
           // }
        //}
        //chkBoxViolence.setOnClickListener {
           // if (chkBoxViolence.isChecked == true)
            //{
               // checkBoxViol = chkBoxViolence.getText().toString();
           // }
        //}
    //}

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater?.inflate(R.menu.menu_addclear,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.itemId == menuitem_add_to_main) {
            var display_language: String = ""
            var display_suitability: String = ""
            var display_language_used_in_movie: String = ""
            var display_violence_used_in_movie: String = ""
            var intent: Intent? = Intent(this, MovieDetail::class.java)
            intent?.putExtra("message", "Add")
            intent?.putExtra("movie_name", am_movietitleET.text.toString())
            intent?.putExtra("movie_description", am_moviedescriptionET.text.toString())
            intent?.putExtra("movie_release_date", am_moviedateET.text.toString())
            if (am_rbtnEng.isChecked)
                display_language = "English"
            else if (am_rbtnChi.isChecked)
                display_language = "Chinese"
            else if (am_rbtnMal.isChecked)
                display_language = "Malay"
            else if (am_rbtnTam.isChecked)
                display_language = "Tamil"

            intent?.putExtra("movie_language", display_language)

            if (chkBoxAudience.isChecked)
                display_suitability= "Yes"
            else
                display_suitability = "No"
            if (chkBoxViolence.isChecked)
                display_violence_used_in_movie = " (Violence)"
            if (chkBoxLanguage.isChecked)
                display_language_used_in_movie = "  (Language Used)"

            intent?.putExtra("movie_suitability",  display_suitability+display_violence_used_in_movie+display_language_used_in_movie)
            startActivity(intent)
        }

       if (item?.itemId == menuitem_clear_from_main)
    {
        am_movietitleET.setText("")
        am_moviedescriptionET.setText("")
        am_moviedateET.setText("")
        am_movielanguageRG.clearCheck()
        am_rbtnEng.setChecked(true)
        chkBoxAudience.setChecked(false)
        chkBoxViolence.setChecked(false)
        chkBoxLanguage.setChecked(false)
        chkBoxViolence.setVisibility(View.INVISIBLE)
        chkBoxLanguage.setVisibility(View.INVISIBLE)
    }
        return super.onOptionsItemSelected(item)
    }

    //fun displayToast(message: String) {
        //Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    //}


}


