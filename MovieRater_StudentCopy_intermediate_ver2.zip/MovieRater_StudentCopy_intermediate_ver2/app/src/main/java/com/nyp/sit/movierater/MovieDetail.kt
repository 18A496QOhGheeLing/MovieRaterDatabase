package com.nyp.sit.movierater

import android.app.Activity
import android.content.Intent
import android.os.Build.VERSION_CODES.N
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.RatingBar
import android.widget.TextView
import com.nyp.sit.movierater.R.id.*
import com.nyp.sit.movierater.data.MovieRating
import kotlinx.android.synthetic.main.activity_movie_detail.*
import kotlinx.android.synthetic.main.activity_rating.*


class MovieDetail : AppCompatActivity() {


    var mrApp :MovieRaterApplication ?= null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)
        this.actionBar?.setDisplayHomeAsUpEnabled(true)
        mrApp = MovieRaterApplication.getInstance()



        registerForContextMenu(press_add_reviewTV)

        var FromActivty = intent.getStringExtra("message")
        if (FromActivty == "Add" || FromActivty == "Edit")
        {
            movienameTV.text = intent.getStringExtra("movie_name")
            overviewTV.text = intent.getStringExtra("movie_description")
            releasedateTV.text = intent.getStringExtra("movie_release_date")
            languageTV.text = intent.getStringExtra("movie_language")
            suitabilityTV.text = intent.getStringExtra("movie_suitability")
            no_reviewTV.text = "No Reviews yet"
            if (no_reviewTV.text == "No Review yet" || no_reviewTV.text=="") {
                md_ratingBar.setVisibility(View.GONE) }
            }
            else
            { var description_temporary: String = "This movie involves many people hitting each other"
               var Movie = MovieRating ("Avenger", description_temporary,
                       "English", "2010", true, false)
                if (Movie.violent == false)
                { suitabilityTV.text = " No(Violence)" }
                movienameTV.text = Movie.name
                overviewTV.text = Movie.description
                languageTV.text = Movie.langauge
                releasedateTV.text = Movie.releasedate
                no_reviewTV.text = "No Reviews yet"
                md_ratingBar.setVisibility(View.GONE)
            }
        }



    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu?.add(0,0,0,"Add Review")

        }

    override fun onContextItemSelected(item: MenuItem?): Boolean {
        var intent: Intent? = Intent(this, RatingActivity::class.java)
        intent?.putExtra("message", "Details")
        intent?.putExtra("movie_title", movienameTV.text)
        startActivityForResult(intent,0)
        return super.onContextItemSelected(item)
        }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0)
            when (resultCode){
                RESULT_OK-> {no_reviewTV.text = data?.getStringExtra("Ratings_details")
             var rbstars = data?.getFloatExtra("Ratings_stars", 1.0f)
                    md_ratingBar.rating = rbstars!!
                    md_ratingBar.setVisibility(View.VISIBLE)
                    md_ratingBar.rating = 2.0f
                    press_add_reviewTV.setVisibility(View.GONE)

                }
            }
    }
}



